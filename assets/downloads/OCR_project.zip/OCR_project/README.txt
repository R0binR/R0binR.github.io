to launch the project :
give the permission and then launch the 
./sudoku
